var dashboard;
$(document).on('ready page:change', function() {
	
});
