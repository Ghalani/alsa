/*var dashboard;
var org_num;
$(document).on('ready page:change', function() {
	show = new Vue({
	  el: '#organization-show',
	  data: {
	  	users: {
		    nonMembers: [],
		    Members: []	  		
	  	}
	  },
	  methods:{
	  },
	  ready: function() {
	    //getUsers();
	  }
	});
});*/
;
